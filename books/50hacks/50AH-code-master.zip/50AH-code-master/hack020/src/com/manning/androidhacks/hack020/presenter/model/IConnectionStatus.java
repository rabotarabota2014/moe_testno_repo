/*******************************************************************************
 * Copyright (c) 2012 Manning
 * See the file license.txt for copying permission.
 ******************************************************************************/
package com.manning.androidhacks.hack020.presenter.model;

public interface IConnectionStatus {
  boolean isOnline();
}
