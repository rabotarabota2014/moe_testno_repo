import com.manning.androidhacks.hack050
import org.scalatest.matchers.ShouldMatchers
import org.scalatest.Spec

class Specs extends Spec with ShouldMatchers {
  describe("a spec") {
    it("should do something") {
    }
  }
}