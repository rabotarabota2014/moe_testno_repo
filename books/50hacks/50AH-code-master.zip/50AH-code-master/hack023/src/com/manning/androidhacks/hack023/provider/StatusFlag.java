/*******************************************************************************
 * Copyright (c) 2012 Manning
 * See the file license.txt for copying permission.
 ******************************************************************************/
package com.manning.androidhacks.hack023.provider;

public class StatusFlag {
  public static final int CLEAN = 0;
  public static final int MOD = 1;
  public static final int ADD = 2;
  public static final int DELETE = 3;
}
