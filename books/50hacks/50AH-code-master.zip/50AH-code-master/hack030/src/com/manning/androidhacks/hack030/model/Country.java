/*******************************************************************************
 * Copyright (c) 2012 Manning
 * See the file license.txt for copying permission.
 ******************************************************************************/
package com.manning.androidhacks.hack030.model;

public class Country {
  private String name;

  public Country() {

  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

}
